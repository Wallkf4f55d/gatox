package com.jacekun

import com.lagradost.cloudstream3.MainAPI
import com.lagradost.cloudstream3.TvType

class Example : MainAPI() {
    private val DEV = "DevDebug"
    private val globaltvType = TvType.Movie
}